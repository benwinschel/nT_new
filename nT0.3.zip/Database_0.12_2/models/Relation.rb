class Relation < ActiveRecord::Base
    belongs_to :users
end
