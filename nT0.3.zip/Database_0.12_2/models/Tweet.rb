class Tweet < ActiveRecord::Base
    belongs_to :users
end
