class Integer
  def to_b
    return !self.zero?
  end
end
