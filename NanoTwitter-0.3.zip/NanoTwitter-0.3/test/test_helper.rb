ENV["RAILS_ENV"] ||= 'test' 
ENV['RACK_ENV'] = 'test'

require 'minitest/autorun'
require 'rack/test'

require_relative '../app.rb'
